﻿using System;

public class Class1
{
	
    Student st = new Student();
}
