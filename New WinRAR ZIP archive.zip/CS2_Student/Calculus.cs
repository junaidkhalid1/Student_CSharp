﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CS2_Student
{
    class Calculus
    {
        public int powtwo(int s)
        {
            int a = s * s;
            return a;
        }

        public int powthree(int s)
        {
            int a = s * s * s;
            return a;
        }

        public int powfour(int s)
        {
            int a = s * s * s * s;
            return a;
        }

    }
}
